import Vue from 'vue';

export default function Message(msg) {
  const el = document.createElement('div');
  const vm = new Vue({
    render() {
      return (
        <transition name="fade">
          <div
            class="msg-cover"
            v-show={this.show}
            v-on:animationend={this.onAnimationEnd}>
            <div class="msg">{msg}</div>
          </div>
        </transition>
      );
    },
    data() {
      return {
        show: false,
      };
    },
    mounted() {
      this.open();
    },
    methods: {
      open() {
        this.show = true;
        setTimeout(() => {
          this.close();
        }, 3000);
      },
      close() {
        this.show = false;
      },
      onAnimationEnd() {
        if (!this.show) {
          this.$el.remove();
        }
      },
    },
  });
  document.body.appendChild(el);
  vm.$mount(el);
  return vm;
}
