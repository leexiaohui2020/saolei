<template>
  <div class="flink">
    <a
      class="flink-item"
      target="_blank"
      :key="k"
      :href="v.link"
      :title="v.name"
      v-for="(v, k) of flinks"
    >{{ v.name }}</a>
  </div>
</template>

<style lang="less" scoped>
@import './index.less';
</style>

<script>
export default {
  name: 'Flink',
  data() {
    return {
      flinks: [],
    };
  },
  async mounted() {
    await this.getFlinks();
  },
  methods: {
    async getFlinks() {
      const { data } = await this.$http.post('/api2022');
      if (data.status === 'ok') {
        this.flinks = data.data.slice(0);
      }
    },
  },
};
</script>
