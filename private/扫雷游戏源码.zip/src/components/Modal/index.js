import Vue from 'vue';
import Modal from './modal.vue';

function createVueInstance(opts = {}) {
  const el = document.createElement('div');
  const vm = new Vue({
    data() {
      return Object.assign(opts.data || {}, {
        actions: (opts.actions || []).map(item => Object.assign({
          disabled: false,
          loading(text) {
            const source = this.text;
            this.text = text;
            this.disabled = true;
            return () => {
              this.text = source;
              this.disabled = false;
            };
          },
        }, item)),
      });
    },
    render(h) {
      const buttons = vm.actions.map((item) => {
        const className = item.disabled ? 'btn disabled' : 'btn';
        const onClick = () => {
          if (typeof item.onClick === 'function') {
            item.onClick.call(vm, item);
          }
        };
        return (
          <button slot="footer" class={className} v-on:click={onClick}>
            <span>{item.text}</span>
          </button>
        );
      });

      return (
        <Modal ref="modal" title={opts.title} v-on:change={vm.onChange}>
          {opts.render ? opts.render(h) : ''}
          {buttons}
        </Modal >
      );
    },
    mounted() {
      this.open();
    },
    methods: {
      open() { this.$refs.modal.open(); },
      close() { this.$refs.modal.close(); },
      onChange(flag) {
        if (!flag) {
          this.$el.remove();
        }
      },
    },
  });

  document.body.appendChild(el);
  vm.$mount(el);
  return vm;
}

export default {

  create: createVueInstance,

  alert: (message, title, okText) => (
    new Promise((resolve) => {
      createVueInstance({
        title,
        render: h => h('div', message),
        actions: [{
          text: okText || '确定',
          onClick() {
            this.close();
            resolve();
          },
        }],
      });
    })
  ),
};
