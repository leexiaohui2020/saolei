import Vue from 'vue';
import Modal from './modal.vue';

function createVueInstance(opts = {}) {
  const el = document.createElement('div');
  const vm = new Vue({
    render: h => h(Modal, {
      ref: 'modal',
      on: {
        change(flag) {
          if (!flag) {
            vm.$el.remove();
          }
        },
      },
      props: {
        title: opts.title,
      },
    }, [opts.render(h)].concat((opts.actions || []).map(item => h('button', {
      staticClass: 'btn',
      on: {
        click: item.onClick,
      },
      slot: 'footer',
    }, item.text)))),
    methods: {
      open() {
        return this.$refs.modal && this.$refs.modal.open();
      },
      close() {
        return this.$refs.modal && this.$refs.modal.close();
      },
    },
  });

  document.body.appendChild(el);
  vm.$mount(el);
  return vm;
}

export default {

  alert: (message, title, okText) => new Promise((resolve) => {
    const modal = createVueInstance({
      title,
      render: h => h('div', message),
      actions: [{
        text: okText || '确定',
        onClick() {
          modal.close();
          resolve();
        },
      }],
    });
    modal.open();
  }),

  create: createVueInstance,
};
