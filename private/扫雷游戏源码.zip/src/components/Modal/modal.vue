<template>
  <div class="modal-mask" @mousedown="maskHandler">
    <transition
      enter-active-class="animated faster fadeInDown"
      leave-active-class="animated faster fadeOutUp">
      <div v-show="show" class="modal" :class="{ focus: isFocus }" @animationend="onAnimationEnd">
        <div class="modal-header">
          <span class="modal-header-title">{{ title }}</span>
          <a href="javascript:;" class="modal-header-close" @click="close">&times;</a>
        </div>
        <div class="modal-container">
          <slot />
          <div class="modal-footer" v-if="showFooter">
            <slot name="footer" />
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<style lang="less">
@import './modal.less';
</style>

<script>
export default {
  name: 'Modal',
  props: {
    title: String,
  },
  data() {
    return {
      show: false,
      isFocus: true,
    };
  },
  computed: {
    showFooter() {
      return this.$slots.footer && this.$slots.footer.length;
    },
  },
  methods: {
    maskHandler(e) {
      this.isFocus = (e.target !== this.$el);
    },
    onAnimationEnd() {
      this.$emit('change', this.show);
    },
    open() {
      this.show = true;
    },
    close() {
      this.show = false;
    },
  },
};
</script>
