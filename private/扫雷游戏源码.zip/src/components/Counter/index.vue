<template>
  <div class="counter">
    <div
      class="counter-num"
      :class="`num-${v}`"
      :key="k"
      v-for="(v, k) of counter"
    ></div>
  </div>
</template>

<style lang="less" scoped>
@import './index.less';
</style>

<script>
export default {
  name: 'Counter',
  props: {
    value: Number,
  },
  computed: {
    counter() {
      const nums = String(this.value).split('').reverse();
      return Array(3).fill(0).map((v, k) => nums[k] || 0).reverse();
    },
  },
};
</script>
