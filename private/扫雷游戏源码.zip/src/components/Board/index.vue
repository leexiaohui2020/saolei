<template>
  <div class="board" @mousedown.left="leftDownHandler" @mouseup.left="leftUpHandler">
    <div
      class="board-cell"
      :class="{ reverse: reverse.includes(k) }"
      :style="cellStyle"
      :key="k"
      v-for="(v, k) of map"
      @mouseup.left="clickHandler(k)"
      @mouseup.right="rightHandler(k)"
    >
      <div class="board-cell-front" :class="blockClass(k)"></div>
      <div class="board-cell-back" :class="cellClass(k)"></div>
    </div>
  </div>
</template>

<style lang="less" scoped>
@import './index.less';
</style>

<script>
import { getNearIndexes } from '@/helper';

export default {
  name: 'Board',
  props: {
    map: Array,
    help: Array,
    flag: Array,
    reverse: Array,
    errorIndex: Number,
  },
  data() {
    return {
      previews: [],
    };
  },
  computed: {
    cellStyle() {
      const size = `${100 / Math.sqrt(this.map.length)}%`;
      return { width: size, height: size };
    },
  },
  methods: {
    cellClass(k) {
      const type = this.map[k];
      if (this.errorIndex !== -1) {
        if (this.flag.includes(k) && type !== -1) return 'mine-error';
        if (this.errorIndex === k) return 'mine-active';
      }
      if (type === -1) return 'mine';
      return `bn-${type}`;
    },

    blockClass(index) {
      if (this.help.includes(index)) return 'block-help';
      if (this.flag.includes(index)) return 'block-flag';
      if (this.previews.includes(index)) return 'bn-0';
      return 'block';
    },

    clickHandler(index) {
      this.previews = [];
      this.$emit('click', index);
    },

    rightHandler(index) {
      this.$emit('right', index);
    },

    leftDownHandler(e) {
      if (e.target !== this.$el) return;
      if (this.errorIndex !== -1) return;
      const size = Math.sqrt(this.map.length);
      const x = Math.floor(e.offsetX / (this.$el.offsetWidth / size));
      const y = Math.floor(e.offsetY / (this.$el.offsetHeight / size));
      const index = x + size * y;

      if (!this.reverse.includes(index)) return;
      if (this.map[index] < 0) return;

      const nears = getNearIndexes(index, size, size).filter((nearIndex) => {
        if (this.reverse.includes(nearIndex)) return false;
        if (this.flag.includes(nearIndex)) return false;
        if (this.help.includes(nearIndex)) return false;
        return true;
      });
      if (nears.length) {
        this.previews = nears.slice(0);
        this.$el.preview = index;
      }
    },

    leftUpHandler() {
      if (this.previews.length) {
        const index = this.$el.preview;
        this.$emit('nears', index);
        this.$el.preview = null;
      }
      this.previews = [];
    },
  },
};
</script>
