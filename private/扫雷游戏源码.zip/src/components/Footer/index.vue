<template>
  <footer class="footer">
    <div class="footer-row">
      <a href="javascript:;" @click="openCodeModal">源码索取</a>
      <a href="javascript:;" @click="openFLModal">友情链接</a>
      <a href="javascript:;">请喝可乐</a>
    </div>
    <div class="footer-row">
      <span>© {{ year }}</span>
      <a href="javascript:;" @click="openWechatModal">橙续缘</a>
      <a href="http://www.beian.gov.cn/" target="_blank">粤ICP备18083394号</a>
    </div>
  </footer>
</template>

<style lang="less" scoped>
@import './index.less';
</style>

<script>
import axios from 'axios';
import Modal from '../Modal';

export default {
  name: 'Footer',
  data() {
    return {
      year: new Date().getFullYear(),
    };
  },
  methods: {

    // 我的微信
    openWechatModal() {
      Modal.create({
        title: '我的微信',
        render: h => h('img', {
          attrs: { src: '/image/wechat.jpg' },
          style: { width: '100%' },
        }),
      }).open();
    },

    // 申请友链
    openFLModal() {
      const modal = Modal.create({
        title: '申请友链',
        render: () => (
          <form class="form">
            <div class="notice mb-20">
              <span>提交后请将本站添加为贵站首页友链，机器人会定时检查。</span>
            </div>
            <div class="form-item">
              <label class="form-label">网站名称</label>
              <input name="name" class="form-input" required />
            </div>
            <div class="form-item">
              <label class="form-label">网站链接</label>
              <input type="url" name="link" class="form-input" required />
            </div>
          </form>
        ),
        actions: [
          {
            text: '提交',
            async onClick() {
              const form = document.querySelector('.form', modal.$el);
              if (!form.reportValidity()) return;
              const name = form.name.value;
              const link = form.link.value;
              const { data } = await axios.post('/api2020', { name, link });
              Modal.alert(
                data.status === 'ok' ? '提交成功' : data.errmsg,
                data.status === 'ok' ? '提示' : '提交失败',
              );
            },
          },
          { text: '取消', onClick: () => modal.close() },
        ],
      });
      modal.open();
    },

    // 索取源码
    openCodeModal() {
      const modal = Modal.create({
        title: '索取源码',
        render: () => (
          <form class="form">
            <div class="notice mb-20">源码将发送至你的邮箱</div>
            <div class="form-item">
              <label class="form-label">邮箱</label>
              <input name="email" type="email" class="form-input" required />
            </div>
          </form>
        ),
        actions: [
          {
            text: '确定',
            async onClick() {
              const form = document.querySelector('.form', modal.$el);
              if (!form.reportValidity()) return;
              const email = form.email.value;
              const { data } = await axios.post('/api2021', { email });
              Modal.alert(
                data.status === 'ok' ? '源码已发至你的邮箱，请查收！' : data.errmsg,
                data.status === 'ok' ? '提示' : '发送失败',
              );
            },
          },
          { text: '取消', onClick: () => modal.close() },
        ],
      });
      modal.open();
    },
  },
};
</script>
