<template>
  <footer class="footer">
    <div class="footer-row">
      <a href="javascript:;" @click="openCodeModal">源码索取</a>
      <a href="javascript:;" @click="openFLModal">友情链接</a>
      <a href="javascript:;" @click="openAppreciate">请喝可乐</a>
    </div>
    <div class="footer-row">
      <span>© {{ year }}</span>
      <a href="javascript:;" @click="openWechatModal">橙续缘</a>
      <a href="http://www.beian.gov.cn/" target="_blank">粤ICP备18083394号</a>
    </div>
  </footer>
</template>

<style lang="less" scoped>
@import './index.less';
</style>

<script>
import axios from 'axios';
import Modal from '../Modal';
import './apt.less';

export default {
  name: 'Footer',
  data() {
    return {
      year: new Date().getFullYear(),
    };
  },
  methods: {

    // 我的微信
    openWechatModal() {
      Modal.create({
        title: '我的微信',
        render: h => h('img', {
          attrs: { src: '/image/wechat.jpg' },
          style: { width: '100%' },
        }),
      });
    },

    // 申请友链
    openFLModal() {
      Modal.create({
        title: '申请友链',
        render: () => (
          <form class="form">
            <div class="notice mb-20">
              <span>提交后请将本站添加为贵站首页友链，机器人会定时检查。</span>
            </div>
            <div class="form-item">
              <label class="form-label">网站名称</label>
              <input name="name" class="form-input" required />
            </div>
            <div class="form-item">
              <label class="form-label">网站链接</label>
              <input type="url" name="link" class="form-input" required />
            </div>
          </form>
        ),
        actions: [{
          text: '提交',
          async onClick(button) {
            const form = document.querySelector('.form', this.$el);
            if (!form.reportValidity()) return;
            const name = form.name.value;
            const link = form.link.value;
            const loading = button.loading('提交中');
            const { data } = await axios.post('/api2020', { name, link });
            loading();
            Modal.alert(
              data.status === 'ok' ? '提交成功' : data.errmsg,
              data.status === 'ok' ? '提示' : '提交失败',
            );
          },
        }, {
          text: '取消',
          onClick() {
            this.close();
          },
        }],
      });
    },

    // 索取源码
    openCodeModal() {
      Modal.create({
        title: '索取源码',
        render: () => (
          <form class="form">
            <div class="notice mb-20">源码会发送到你的邮箱，请注意查收。</div>
            <div class="form-item">
              <label class="form-label">邮箱</label>
              <input name="email" type="email" class="form-input" required />
            </div>
          </form>
        ),
        actions: [{
          text: '确定',
          async onClick(button) {
            const form = document.querySelector('.form', this.$el);
            if (!form.reportValidity()) return;
            const email = form.email.value;
            const loading = button.loading('提交中');
            const { data } = await axios.post('/api2021', { email });
            loading();
            Modal.alert(
              data.status === 'ok' ? '源码已发至你的邮箱，请查收！' : data.errmsg,
              data.status === 'ok' ? '提示' : '发送失败',
            );
          },
        }, {
          text: '取消',
          onClick() {
            this.close();
          },
        }],
      });
    },

    // 请喝可乐
    openAppreciate() {
      const data = { tab: 0 };
      const click0 = () => { data.tab = 0; };
      const click1 = () => { data.tab = 1; };
      Modal.create({
        data,
        title: '请喝可乐',
        render: () => (
          <div class="apt">
            <div class="apt-tab">
              <button class={data.tab === 0 ? 'btn disabled' : 'btn'} v-on:click={click0}>微信</button>
              <button class={data.tab === 1 ? 'btn disabled' : 'btn'} v-on:click={click1}>支付宝</button>
            </div>
            <img class="apt-qrcode" src={data.tab === 0 ? '/image/wx.png' : '/image/zfb.jpg'} />
          </div>
        ),
      });
    },
  },
};
</script>
