<template>
  <div class="app">
    <!-- 状态栏 -->
    <header class="app-header">
      <Counter :value="orderMineCount" />
      <div class="app-action block" @click="restart">
        <div class="face" :class="faceClass"></div>
      </div>
      <Counter :value="time | time" />
    </header>

    <!-- 扫雷区 -->
    <main class="app-container">
      <Board
        class="app-board"
        :map="map"
        :flag="flag"
        :help="help"
        :reverse="reverse"
        :error-index="errorIndex"
        @click="clickHandler"
        @right="rightHandler"
        @nears="nearsHandler"
      />
    </main>

    <!-- 说明栏 -->
    <aside class="app-side">
      <h2 class="app-side-title">游戏规则</h2>
      <p class="app-side-content">经典扫雷，一款好玩有趣还能提高自己智力的小游戏，是你娱乐休闲打发时间的绝佳游戏，一起来玩吧！</p>

      <h2 class="app-side-title">游戏目标</h2>
      <p class="app-side-content">合理操作，扫除所有地雷。</p>

      <h2 class="app-side-title">操作指南</h2>
      <p class="app-side-content">鼠标左键点击，右键标注；右键可标注雷或问号，问号代表不确定。游戏左方数字代表雷数，右方数字代表时间。</p>

      <button class="btn" @click="switchLevel">游戏难度：{{ gameConfig.text }}</button>
    </aside>

    <!-- Footer -->
    <Footer />
  </div>
</template>

<style lang="less" scoped>
@import './app.less';
</style>

<script>
import Board from './components/Board/index.vue';
import Counter from './components/Counter/index.vue';
import Footer from './components/Footer/index.vue';
import { getNearIndexes, removeFrom } from './helper';

export default {
  name: 'App',
  components: {
    Board,
    Counter,
    Footer,
  },
  data() {
    return {
      map: [],
      flag: [], // 标注雷的坐标
      help: [], // 标注问号的坐标
      reverse: [], // 翻转的坐标
      errorIndex: -1, // 碰到雷的坐标，失败
      isWin: false, // 胜利
      time: 0, // 时间
      level: 0, // 游戏难度
    };
  },
  computed: {
    mapSize() {
      return Math.sqrt(this.map.length);
    },
    mapInited() {
      return this.map.filter(v => !!v).length > 0;
    },
    isOver() {
      return this.errorIndex !== -1 || this.isWin;
    },
    orderMineCount() {
      return this.gameConfig.mineNum - this.flag.length;
    },
    faceClass() {
      if (this.isWin) return 'face-win';
      if (this.isOver) return 'face-fail';
      return 'face';
    },
    gameConfig() {
      let size;
      let text;
      let mineNum;

      switch (this.level) {
        case 2:
          size = 22;
          mineNum = 100;
          text = '高级';
          break;
        case 1:
          size = 16;
          mineNum = 40;
          text = '中级';
          break;
        default:
          size = 9;
          mineNum = 10;
          text = '初级';
          break;
      }
      return { size, mineNum, text };
    },
  },
  watch: {
    reverse(list) {
      if (this.map.length - list.length === this.gameConfig.mineNum) {
        this.gameWin();
      }
    },
    isOver(flag) {
      if (flag && this.timerId) {
        clearInterval(this.timerId);
        this.timerId = null;
      }
    },
  },
  mounted() {
    this.restart();
  },
  destroyed() {
    clearInterval(this.timerId);
  },
  methods: {

    createMap(size, mineNum, initIndex) {
      const map = new Array(size * size).fill(0);
      const used = [];
      while (used.length < mineNum) {
        const index = Math.ceil(Math.random() * (map.length - 1));
        if (!used.includes(index) && index !== initIndex) {
          used.push(index);
          map[index] = -1;
        }
      }

      this.map = map.map((v, k) => {
        if (v !== -1) {
          return getNearIndexes(k, size, size).reduce((count, index) => {
            if (map[index] === -1) return count + 1;
            return count;
          }, 0);
        }
        return v;
      });
      this.reverseItem(initIndex);
      this.time = 1;
      this.timerId = setInterval(() => {
        this.time += 1;
      }, 1000);
    },

    reverseItem(index) {
      if (this.isOver) return;
      if (this.reverse.includes(index)) return;
      if (this.flag.includes(index)) return;
      if (this.help.includes(index)) return;

      this.reverse.push(index);
      if (this.map[index] === -1) {
        this.gameOver(index);
        return;
      }
      if (this.map[index] === 0) {
        const size = this.mapSize;
        const nears = getNearIndexes(index, size, size);
        nears.forEach((nearIndex) => {
          this.reverseItem(nearIndex);
        });
      }

      this.reverse.forEach((item) => {
        removeFrom(this.flag, item);
        removeFrom(this.help, item);
      });
    },

    clickHandler(index) {
      if (this.isOver) return;
      if (this.mapInited) {
        this.reverseItem(index);
      } else {
        this.createMap(this.gameConfig.size, this.gameConfig.mineNum, index);
      }
    },

    rightHandler(index) {
      if (this.isOver) return;
      if (this.flag.includes(index)) {
        removeFrom(this.flag, index);
        this.help.push(index);
      } else if (this.help.includes(index)) {
        removeFrom(this.help, index);
      } else if (this.orderMineCount > 0) {
        this.flag.push(index);
      }
    },

    nearsHandler(index) {
      if (this.isOver) return;
      if (!this.mapInited) return;
      const size = Math.sqrt(this.map.length);
      const nears = getNearIndexes(index, size, size);
      const flagNum = nears.reduce((count, nearsIndex) => {
        if (this.flag.includes(nearsIndex)) return count + 1;
        return count;
      }, 0);
      if (this.map[index] > 0 && flagNum === this.map[index]) {
        nears.forEach(this.reverseItem);
      }
    },

    gameOver(index) {
      this.errorIndex = index;
      this.reverse = Array(this.map.length).fill(0).map((v, k) => k);
    },

    gameWin() {
      this.isWin = true;
      this.$alert(
        `游戏胜利！！！用时：${this.time}秒`,
        '提示',
        '重新开始',
      ).then(() => this.restart());
    },

    restart() {
      clearInterval(this.timerId);
      this.flag = [];
      this.help = [];
      this.reverse = [];
      this.errorIndex = -1;
      this.isWin = false;
      this.time = 0;
      this.map = Array(this.gameConfig.size * this.gameConfig.size);
    },

    switchLevel() {
      let level = this.level + 1;
      if (level > 2) level = 0;
      this.level = level;
      this.restart();
    },
  },
  filters: {
    time(value) {
      return value % 1000;
    },
  },
};
</script>
