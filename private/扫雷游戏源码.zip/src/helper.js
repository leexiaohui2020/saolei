export function getNearIndexes(index, maxX, maxY) {
  const nears = [];
  const x = index % maxX;
  const y = Math.floor(index / maxY);

  const top = y > 0;
  const left = x > 0;
  const right = x < maxX - 1;
  const bottom = y < maxY - 1;

  if (top) nears.push(index - maxY);
  if (left) nears.push(index - 1);
  if (right) nears.push(index + 1);
  if (bottom) nears.push(index + maxY);
  if (top && left) nears.push(index - maxY - 1);
  if (top && right) nears.push(index - maxY + 1);
  if (bottom && left) nears.push(index + maxY - 1);
  if (bottom && right) nears.push(index + maxY + 1);
  return nears;
}

/** @param {Array} arr */
export function removeFrom(arr, item) {
  const index = arr.indexOf(item);
  if (index === -1) return false;
  arr.splice(index, 1);
  return true;
}
