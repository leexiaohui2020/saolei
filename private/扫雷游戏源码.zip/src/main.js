import Vue from 'vue';
import axios from 'axios';
import App from './app.vue';
import Modal from './components/Modal';
import './less/main.less';
import 'vue2-animate/dist/vue2-animate.min.css';

Vue.prototype.$http = axios;
Vue.prototype.$alert = Modal.alert;

new Vue({
  render: h => h(App),
}).$mount('#app');

window.oncontextmenu = e => e.preventDefault();
