module.exports = {
  outputDir: '../saolei-server/public',
  devServer: {
    proxy: {
      '/': {
        target: 'http://localhost:20201',
      },
    },
  },
};
